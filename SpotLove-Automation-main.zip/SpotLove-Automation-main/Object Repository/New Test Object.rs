<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>New Test Object</name>
   <tag></tag>
   <elementGuidId>d8534748-b9f5-4f7c-8f9f-441a6fc9fa44</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[contains(@class,&quot;MuiPickersClockPointer-pointer&quot;)]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[contains(@class,&quot;MuiPickersClockPointer-pointer&quot;)]</value>
      <webElementGuid>1124d613-4b7b-452f-8d41-2eefd717ed38</webElementGuid>
   </webElementProperties>
</WebElementEntity>
