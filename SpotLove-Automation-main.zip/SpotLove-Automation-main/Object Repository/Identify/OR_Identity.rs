<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>OR_Identity</name>
   <tag></tag>
   <elementGuidId>bebd756d-4131-4396-a69d-f4ee4f78adc6</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator></locator>
   <locatorStrategy>CUSTOM</locatorStrategy>
</MobileElementEntity>
