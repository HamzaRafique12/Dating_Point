<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>New Test Object</name>
   <tag></tag>
   <elementGuidId>cbafc4aa-0c29-46d7-80eb-8098a0baba5c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'android.widget.TextView' and (@text = 'Non-Binary' or . = 'Non-Binary')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@class = 'android.widget.TextView' and (@text = 'Non-Binary' or . = 'Non-Binary')]</value>
      <webElementGuid>bbf1d4d3-c431-42bc-8f50-bfce1c00ddf0</webElementGuid>
   </webElementProperties>
</WebElementEntity>
